function instructionScreen() {
    background('crimson');

}